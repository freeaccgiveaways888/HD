import { BalancePipe } from './balance.pipe';

describe('BalancePipe', () => {
  it('create an instance', () => {
    const pipe = new BalancePipe();
    expect(pipe).toBeTruthy();
  });
});
