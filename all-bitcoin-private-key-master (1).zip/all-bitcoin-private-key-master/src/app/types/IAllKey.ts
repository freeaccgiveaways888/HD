export interface IAllKey {
  id: string;
  privateKey: string;
  addressUnCompressed: string;
  addressUnCompressedBalance: string;
  addressUnCompressedReceived: string;
  addressCompressed: string;
  addressCompressedBalance: string;
  addressCompressedReceived: string;
}
