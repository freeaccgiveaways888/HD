export interface IBlockchain {
  string: {
    final_balance: number
    n_tx: number
    total_received: number
  }
}
